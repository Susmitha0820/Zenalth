(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_ff39e716._.js",
  "static/chunks/node_modules_recharts_es6_ffed4bcc._.js",
  "static/chunks/node_modules_38b809cb._.js",
  "static/chunks/src_0f248de3._.js"
],
    source: "dynamic"
});

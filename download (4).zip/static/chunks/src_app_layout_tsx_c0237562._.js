(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__dc687cf0._.css",
  "static/chunks/node_modules_663f12bf._.js",
  "static/chunks/src_52633624._.js"
],
    source: "dynamic"
});
